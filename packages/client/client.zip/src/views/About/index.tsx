const AboutView: React.FC = () => (
  <div>
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Iste quod culpa dolores esse quis beatae cupiditate
    commodi, id vitae tenetur, facilis dicta iusto atque, animi soluta consequatur! Officia, ab rerum!
  </div>
);

export default AboutView;
