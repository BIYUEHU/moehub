export const MAIN_COLOR = '#227D51';

export const MAIN_COLOR_DEEP = '#096148';

export const PRIMARY_COLOR = '#0077B6';
