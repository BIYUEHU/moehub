export default {
  url: 'http://localhost:5000/api'
}
